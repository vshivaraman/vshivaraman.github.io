# 2DVTOL_Control - Part of Control Systems Course Project
This repo contains a Python implementation of various control algorithms like PID controller and Full-State Feedback Controller on a 2D VTOL.

![VTOL](https://github.com/vshivaraman/2DVTOL_Control/assets/54199584/0db1e671-6360-4512-947a-8d96f586d29c)



